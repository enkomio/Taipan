function extension_getRequestByUrl(urls,callback){function onHAR(response){var entries=response.entries;for(var i=0;i<entries.length;++i){for(var url=0;url<urls.length;++url){if(urls[url].test(entries[i].request.url)){callback(entries[i]);return;}}}
output('no item found');callback(null);}
webInspector.network.getHAR(onHAR);};var extensionsHost='devtools-extensions.oopif.test';var extensionsOrigin=`http://${extensionsHost}:8000`;Extensions.extensionServer._registerHandler('evaluateForTestInFrontEnd',onEvaluate);Extensions.extensionServer._extensionAPITestHook=function(extensionServerClient,coreAPI){window.webInspector=coreAPI;window._extensionServerForTests=extensionServerClient;coreAPI.panels.themeName='themeNameForTest';};ExtensionsTestRunner._replyToExtension=function(requestId,port){Extensions.extensionServer._dispatchCallback(requestId,port);};function onEvaluate(message,port){try{eval(message.expression);}catch(e){TestRunner.addResult('Exception while running: '+message.expression+'\n'+(e.stack||e));TestRunner.completeTest();}}
ExtensionsTestRunner.runExtensionTests=async function(){var result=await TestRunner.RuntimeAgent.evaluate('location.href','console',false);if(!result)
return;var pageURL=result.value;var extensionURL=((/^https?:/.test(pageURL)?pageURL.replace(/^(https?:\/\/[^\/]*\/).*$/,'$1'):pageURL.replace(/\/inspector\/extensions\/[^\/]*$/,'/http/tests')))+'inspector/resources/extension-main.html';extensionURL=extensionURL.replace('127.0.0.1',extensionsHost);InspectorFrontendAPI.addExtensions([{startPage:extensionURL,name:'test extension',exposeWebInspectorNamespace:true}]);Extensions.extensionServer.initializeExtensions();};TestRunner.initAsync(async function(){await TestRunner.evaluateInPagePromise(`
    function extensionFunctions() {
      var functions = '';

      for (symbol in window) {
        if (/^extension_/.exec(symbol) && typeof window[symbol] === 'function')
          functions += window[symbol].toString();
      }

      return functions;
    }

    var extensionsOrigin = 'http://devtools-extensions.oopif.test:8000';

    function extension_showPanel(panelId, callback) {
      evaluateOnFrontend('InspectorTest.showPanel(unescape(\'' + escape(panelId) + '\')).then(function() { reply(); });', callback);
    }

    var test = function() {
      Common.moduleSetting('shortcutPanelSwitch').set(true);
      InspectorTest.runExtensionTests();
    };
  `);});;ExtensionsTestRunner.startExtensionAudits=function(callback){const launcherView=UI.panels.audits._launcherView;launcherView._selectAllClicked(false);launcherView._auditPresentStateElement.checked=true;var extensionCategories=document.querySelectorAll('.audit-categories-container > label');for(var i=0;i<extensionCategories.length;++i){var shouldBeEnabled=extensionCategories[i].textContent.includes('Extension');if(!shouldBeEnabled&&extensionCategories[i].textElement)
shouldBeEnabled=extensionCategories[i].textElement.textContent.includes('Extension');if(shouldBeEnabled!==extensionCategories[i].checkboxElement.checked)
extensionCategories[i].checkboxElement.click();}
function onAuditsDone(){AuditsTestRunner.collectAuditResults(callback);}
TestRunner.addSniffer(UI.panels.audits,'auditFinishedCallback',onAuditsDone,true);launcherView._launchButtonClicked();};ExtensionsTestRunner.dumpAuditProgress=function(){var progress=document.querySelector('.progress-indicator').shadowRoot.querySelector('progress');TestRunner.addResult('Progress: '+Math.round(100*progress.value/progress.max)+'%');};TestRunner.initAsync(async function(){await TestRunner.evaluateInPagePromise(`
    function extension_runAudits(callback) {
      evaluateOnFrontend('InspectorTest.startExtensionAudits(reply);', callback);
    }
  `);});;